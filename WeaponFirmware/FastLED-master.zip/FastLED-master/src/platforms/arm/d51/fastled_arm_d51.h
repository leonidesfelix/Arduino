#ifndef __INC_FASTLED_ARM_D51_H
#define __INC_FASTLED_ARM_D51_H

#include "fastpin_arm_d51.h"
#include "../../fastspi_ardunio_core.h"
#include "clockless_arm_d51.h"

#endif
